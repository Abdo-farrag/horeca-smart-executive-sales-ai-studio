import { callAnalyticsRpc } from './client';
import { normalizeMonthStart, assertIsoDate } from './validation';
import { toFiniteNumber } from './normalizers';
import {
  CustomerRetentionSummaryResult,
  CustomerSummaryParams,
  CustomerSummaryResult,
  Customer360Params,
  Customer360Result,
  CustomerTrendParams,
  CustomerTrendResult,
  CustomerOrderParams,
  CustomerOrderResult,
  CustomerBuyingFrequencyParams,
  CustomerBuyingFrequencyResult,
  CustomerFavoriteProductsParams,
  CustomerFavoriteProductsResult,
  CustomerSalespersonHistoryParams,
  CustomerSalespersonHistoryResult,
  CustomerRiskParams,
  CustomerRiskResult,
  CustomerProductDropoffParams,
  CustomerProductDropoffResult,
  CustomerCrossSellCandidatesParams,
  CustomerCrossSellCandidatesResult,
  CustomerPortfolioSummaryParams,
  CustomerPortfolioSummaryResult,
  CustomerRiskDistributionParams,
  CustomerRiskDistributionResult,
  CustomerActionCenterParams,
  CustomerActionCenterResult,
  CustomerRecoveryOpportunitiesParams,
  CustomerRecoveryOpportunitiesResult,
} from './types';

export interface CustomerRetentionParams {
  month: string;
  companyName?: string | null;
  salesperson?: string | null;
  governorateCode?: string | null;
  areaCode?: string | null;
  customerId?: number | null;
  productId?: number | null;
}

export const customers = {
  async summary(params: CustomerSummaryParams = {}): Promise<CustomerSummaryResult[]> {
    if (params.startDate) assertIsoDate(params.startDate, 'startDate');
    if (params.endDate) assertIsoDate(params.endDate, 'endDate');

    return callAnalyticsRpc(
      'analytics_customer_summary_v2',
      {
        p_start_date: params.startDate ?? null,
        p_end_date: params.endDate ?? null,
        p_company_name: params.companyName ?? null,
        p_salesperson: params.salesperson ?? null,
        p_governorate_code: params.governorateCode ?? null,
        p_area_code: params.areaCode ?? null,
        p_customer_id: params.customerId ?? null,
        p_product_id: params.productId ?? null,
        p_status: params.status ?? null,
        p_search: params.search ?? null,
        p_limit: params.limit ?? null,
        p_offset: params.offset ?? null,
      },
      (row) => ({
        customerId: toFiniteNumber(row.customer_id, 'customer_id'),
        customerName: String(row.customer_name ?? ''),
        companyName: String(row.company_name ?? ''),
        primarySalesperson: String(row.primary_salesperson ?? ''),
        ordersCount: toFiniteNumber(row.orders_count ?? 0, 'orders_count'),
        salesValue: toFiniteNumber(row.sales_value ?? 0, 'sales_value'),
        averageOrderValue: toFiniteNumber(row.average_order_value ?? 0, 'average_order_value'),
        firstOrderDate: row.first_order_date ? String(row.first_order_date) : null,
        lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
        daysSinceLastOrder: toFiniteNumber(row.days_since_last_order ?? 0, 'days_since_last_order'),
        customerStatus: String(row.customer_status ?? 'ACTIVE'),
        previousPeriodSales: toFiniteNumber(row.previous_period_sales ?? 0, 'previous_period_sales'),
        salesChangePct: row.sales_change_pct != null ? toFiniteNumber(row.sales_change_pct, 'sales_change_pct') : null,
      })
    );
  },

  async get360(params: Customer360Params): Promise<Customer360Result[]> {
    if (params.startDate) assertIsoDate(params.startDate, 'startDate');
    if (params.endDate) assertIsoDate(params.endDate, 'endDate');

    return callAnalyticsRpc(
      'analytics_customer_360',
      {
        p_customer_id: params.customerId,
        p_start_date: params.startDate ?? null,
        p_end_date: params.endDate ?? null,
        p_company_name: params.companyName ?? null,
      },
      (row) => ({
        customerId: toFiniteNumber(row.customer_id, 'customer_id'),
        customerName: String(row.customer_name ?? ''),
        companyName: String(row.company_name ?? ''),
        currentSalesperson: String(row.current_salesperson ?? ''),
        phone: row.phone ? String(row.phone) : null,
        mobile: row.mobile ? String(row.mobile) : null,
        email: row.email ? String(row.email) : null,
        city: row.city ? String(row.city) : null,
        periodOrders: toFiniteNumber(row.period_orders ?? 0, 'period_orders'),
        periodSales: toFiniteNumber(row.period_sales ?? 0, 'period_sales'),
        averageOrderValue: toFiniteNumber(row.average_order_value ?? 0, 'average_order_value'),
        firstOrderDate: row.first_order_date ? String(row.first_order_date) : null,
        lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
        daysSinceLastOrder: toFiniteNumber(row.days_since_last_order ?? 0, 'days_since_last_order'),
        averageDaysBetweenOrders: toFiniteNumber(row.average_days_between_orders ?? 0, 'average_days_between_orders'),
        lifetimeOrders: toFiniteNumber(row.lifetime_orders ?? 0, 'lifetime_orders'),
        lifetimeSales: toFiniteNumber(row.lifetime_sales ?? 0, 'lifetime_sales'),
        uniqueProductsCount: toFiniteNumber(row.unique_products_count ?? 0, 'unique_products_count'),
        customerStatus: String(row.customer_status ?? 'ACTIVE'),
      })
    );
  },

  async trend(params: CustomerTrendParams): Promise<CustomerTrendResult[]> {
    return callAnalyticsRpc(
      'analytics_customer_trend',
      {
        p_customer_id: params.customerId,
        p_company_name: params.companyName ?? null,
      },
      (row) => ({
        orderMonth: String(row.order_month ?? ''),
        ordersCount: toFiniteNumber(row.orders_count ?? 0, 'orders_count'),
        salesValue: toFiniteNumber(row.sales_value ?? 0, 'sales_value'),
        averageOrderValue: toFiniteNumber(row.average_order_value ?? 0, 'average_order_value'),
        activeSalespeople: toFiniteNumber(row.active_salespeople ?? 0, 'active_salespeople'),
      })
    );
  },

  async orders(params: CustomerOrderParams): Promise<CustomerOrderResult[]> {
    if (params.startDate) assertIsoDate(params.startDate, 'startDate');
    if (params.endDate) assertIsoDate(params.endDate, 'endDate');

    return callAnalyticsRpc(
      'analytics_customer_orders',
      {
        p_customer_id: params.customerId,
        p_start_date: params.startDate ?? null,
        p_end_date: params.endDate ?? null,
        p_company_name: params.companyName ?? null,
        p_limit: params.limit ?? null,
        p_offset: params.offset ?? null,
      },
      (row) => ({
        orderId: toFiniteNumber(row.order_id, 'order_id'),
        orderName: String(row.order_name ?? ''),
        orderDate: String(row.order_date ?? ''),
        companyName: String(row.company_name ?? ''),
        salesperson: String(row.salesperson ?? ''),
        orderValue: toFiniteNumber(row.order_value ?? 0, 'order_value'),
        linesCount: toFiniteNumber(row.lines_count ?? 0, 'lines_count'),
        productsCount: toFiniteNumber(row.products_count ?? 0, 'products_count'),
        totalQty: toFiniteNumber(row.total_qty ?? 0, 'total_qty'),
      })
    );
  },

  async buyingFrequency(params: CustomerBuyingFrequencyParams): Promise<CustomerBuyingFrequencyResult[]> {
    return callAnalyticsRpc(
      'analytics_customer_buying_frequency',
      {
        p_customer_id: params.customerId,
        p_company_name: params.companyName ?? null,
      },
      (row) => ({
        ordersCount: toFiniteNumber(row.orders_count ?? 0, 'orders_count'),
        activeDays: toFiniteNumber(row.active_days ?? row.active_purchase_days ?? 0, 'active_days'),
        firstOrderDate: row.first_order_date ? String(row.first_order_date) : null,
        lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
        averageDaysBetweenOrders: toFiniteNumber(row.average_days_between_orders ?? row.avg_days_between_orders ?? 0, 'average_days_between_orders'),
        medianDaysBetweenOrders: toFiniteNumber(row.median_days_between_orders ?? row.median_days ?? 0, 'median_days_between_orders'),
        daysSinceLastOrder: toFiniteNumber(row.days_since_last_order ?? 0, 'days_since_last_order'),
        expectedNextOrderDate: (row.expected_next_order_date || row.expected_next_order) ? String(row.expected_next_order_date || row.expected_next_order) : null,
        frequencyStatus: String(row.frequency_status ?? 'ON_TIME'),
      })
    );
  },

  async favoriteProducts(params: CustomerFavoriteProductsParams): Promise<CustomerFavoriteProductsResult[]> {
    if (params.startDate) assertIsoDate(params.startDate, 'startDate');
    if (params.endDate) assertIsoDate(params.endDate, 'endDate');

    return callAnalyticsRpc(
      'analytics_customer_favorite_products',
      {
        p_customer_id: params.customerId,
        p_start_date: params.startDate ?? null,
        p_end_date: params.endDate ?? null,
        p_company_name: params.companyName ?? null,
        p_limit: params.limit ?? null,
      },
      (row) => ({
        productId: toFiniteNumber(row.product_id, 'product_id'),
        productName: String(row.product_name ?? ''),
        ordersCount: toFiniteNumber(row.orders_count ?? 0, 'orders_count'),
        quantity: toFiniteNumber(row.quantity ?? row.total_qty ?? 0, 'quantity'),
        salesValue: toFiniteNumber(row.sales_value ?? row.sales ?? 0, 'sales_value'),
        salesSharePct: toFiniteNumber(row.sales_share_pct ?? row.sales_share_percent ?? row.share_pct ?? 0, 'sales_share_pct'),
        lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
        primarySalesperson: row.primary_salesperson ? String(row.primary_salesperson) : null,
      })
    );
  },

  async salespersonHistory(params: CustomerSalespersonHistoryParams): Promise<CustomerSalespersonHistoryResult[]> {
    return callAnalyticsRpc(
      'analytics_customer_salesperson_history',
      {
        p_customer_id: params.customerId,
        p_company_name: params.companyName ?? null,
      },
      (row) => ({
        orderMonth: String(row.order_month ?? row.month ?? ''),
        salespersonName: String(row.salesperson_name ?? row.salesperson ?? ''),
        ordersCount: toFiniteNumber(row.orders_count ?? 0, 'orders_count'),
        salesValue: toFiniteNumber(row.sales_value ?? row.sales ?? 0, 'sales_value'),
        firstOrderDate: row.first_order_date ? String(row.first_order_date) : null,
        lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
        isPrimary: Boolean(row.is_primary ?? row.primary_flag ?? false),
      })
    );
  },

  async risk(params: CustomerRiskParams): Promise<CustomerRiskResult[]> {
    return callAnalyticsRpc(
      'analytics_customer_risk',
      {
        p_customer_id: params.customerId,
        p_company_name: params.companyName ?? null,
      },
      (row) => ({
        riskLevel: String(row.risk_level ?? 'LOW'),
        riskReason: String(row.risk_reason ?? row.reason ?? ''),
        recoveryPriority: String(row.recovery_priority ?? row.priority ?? 'LOW'),
        lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
        daysSinceLastOrder: toFiniteNumber(row.days_since_last_order ?? 0, 'days_since_last_order'),
        medianBuyingInterval: toFiniteNumber(row.median_buying_interval ?? row.median_interval ?? 0, 'median_buying_interval'),
        recent30DaySales: toFiniteNumber(row.recent_30day_sales ?? row.recent_30d_sales ?? 0, 'recent_30day_sales'),
        previous30DaySales: toFiniteNumber(row.previous_30day_sales ?? row.previous_30d_sales ?? 0, 'previous_30day_sales'),
        salesChangePct: toFiniteNumber(row.sales_change_pct ?? row.sales_change_percent ?? 0, 'sales_change_pct'),
      })
    );
  },

  async productDropoff(params: CustomerProductDropoffParams): Promise<CustomerProductDropoffResult[]> {
    if (params.startDate) assertIsoDate(params.startDate, 'startDate');
    if (params.endDate) assertIsoDate(params.endDate, 'endDate');

    return callAnalyticsRpc(
      'analytics_customer_product_dropoff',
      {
        p_customer_id: params.customerId,
        p_start_date: params.startDate ?? null,
        p_end_date: params.endDate ?? null,
        p_company_name: params.companyName ?? null,
      },
      (row) => ({
        productId: toFiniteNumber(row.product_id, 'product_id'),
        productName: String(row.product_name ?? ''),
        previousSales: toFiniteNumber(row.previous_sales ?? row.prev_sales ?? 0, 'previous_sales'),
        currentSales: toFiniteNumber(row.current_sales ?? row.curr_sales ?? 0, 'current_sales'),
        previousQuantity: toFiniteNumber(row.previous_quantity ?? row.prev_qty ?? 0, 'previous_quantity'),
        currentQuantity: toFiniteNumber(row.current_quantity ?? row.curr_qty ?? 0, 'current_quantity'),
        salesChangePct: toFiniteNumber(row.sales_change_pct ?? row.change_pct ?? 0, 'sales_change_pct'),
        status: String(row.status ?? row.dropoff_status ?? 'STABLE_OR_GROWING'),
        recoveryValue: toFiniteNumber(row.recovery_value ?? row.recovery_opp ?? 0, 'recovery_value'),
      })
    );
  },

  async crossSellCandidates(params: CustomerCrossSellCandidatesParams): Promise<CustomerCrossSellCandidatesResult[]> {
    if (params.startDate) assertIsoDate(params.startDate, 'startDate');
    if (params.endDate) assertIsoDate(params.endDate, 'endDate');

    return callAnalyticsRpc(
      'analytics_customer_cross_sell_candidates',
      {
        p_customer_id: params.customerId,
        p_start_date: params.startDate ?? null,
        p_end_date: params.endDate ?? null,
        p_company_name: params.companyName ?? null,
        p_limit: params.limit ?? null,
      },
      (row) => ({
        productId: toFiniteNumber(row.product_id, 'product_id'),
        productName: String(row.product_name ?? ''),
        peerCustomersCount: toFiniteNumber(row.peer_customers_count ?? row.peer_customers ?? 0, 'peer_customers_count'),
        peerOrdersCount: toFiniteNumber(row.peer_orders_count ?? row.peer_orders ?? 0, 'peer_orders_count'),
        peerSalesValue: toFiniteNumber(row.peer_sales_value ?? row.peer_sales ?? 0, 'peer_sales_value'),
        affinityScore: toFiniteNumber(row.affinity_score ?? row.score ?? 0, 'affinity_score'),
      })
    );
  },

  async retention(params: CustomerRetentionParams): Promise<CustomerRetentionSummaryResult[]> {
    const normalizedMonth = normalizeMonthStart(params.month, 'month');

    const mapper = (row: any) => ({
      previousActiveCustomers: toFiniteNumber(row.previous_active_customers ?? 0, 'previous_active_customers'),
      retainedWithSameRep: toFiniteNumber(row.retained_with_same_rep ?? 0, 'retained_with_same_rep'),
      transferredCustomers: toFiniteNumber(row.transferred_customers ?? 0, 'transferred_customers'),
      trueLostCustomers: toFiniteNumber(row.true_lost_customers ?? 0, 'true_lost_customers'),
      newCustomers: toFiniteNumber(row.new_customers ?? 0, 'new_customers'),
      companyRetentionRate: toFiniteNumber(row.company_retention_rate ?? 0, 'company_retention_rate'),
      sameRepRetentionRate: toFiniteNumber(row.same_rep_retention_rate ?? 0, 'same_rep_retention_rate'),
      lostCustomerRevenueEgp: toFiniteNumber(row.lost_customer_revenue_egp ?? 0, 'lost_customer_revenue_egp'),
    });

    try {
      return await callAnalyticsRpc(
        'analytics_customer_retention_summary_v2',
        {
          p_month: normalizedMonth,
          p_company_name: params.companyName ?? null,
          p_salesperson: params.salesperson ?? null,
          p_governorate_code: params.governorateCode ?? null,
          p_area_code: params.areaCode ?? null,
          p_customer_id: params.customerId ?? null,
          p_product_id: params.productId ?? null,
        },
        mapper
      );
    } catch (_err: any) {
      return await callAnalyticsRpc(
        'analytics_customer_retention_summary',
        {
          p_month: normalizedMonth,
          p_company_name: params.companyName ?? null,
          p_salesperson: params.salesperson ?? null,
        },
        mapper
      );
    }
  },

  async portfolioSummary(params: CustomerPortfolioSummaryParams = {}): Promise<CustomerPortfolioSummaryResult[]> {
    if (params.asOfDate) assertIsoDate(params.asOfDate, 'asOfDate');

    return callAnalyticsRpc(
      'analytics_customer_portfolio_summary',
      {
        p_as_of_date: params.asOfDate ?? null,
        p_company_name: params.companyName ?? null,
        p_salesperson: params.salesperson ?? null,
      },
      (row) => ({
        totalCustomers: toFiniteNumber(row.total_customers ?? 0, 'total_customers'),
        highPriority: toFiniteNumber(row.high_priority ?? row.high_priority_count ?? 0, 'high_priority'),
        mediumPriority: toFiniteNumber(row.medium_priority ?? row.medium_priority_count ?? 0, 'medium_priority'),
        lowPriority: toFiniteNumber(row.low_priority ?? row.low_priority_count ?? 0, 'low_priority'),
        winBackCustomers: toFiniteNumber(row.win_back_customers ?? row.winback_customers ?? 0, 'win_back_customers'),
        decliningCustomers: toFiniteNumber(row.declining_customers ?? 0, 'declining_customers'),
        overdueCustomers: toFiniteNumber(row.overdue_customers ?? 0, 'overdue_customers'),
        salespersonTransferReviews: toFiniteNumber(
          row.salesperson_transfer_reviews ?? row.owner_transfer_customers ?? row.transfer_reviews ?? 0,
          'salesperson_transfer_reviews'
        ),
        totalRecoveryOpportunity: toFiniteNumber(
          row.total_recovery_opportunity ?? row.total_recovery_opportunity_egp ?? 0,
          'total_recovery_opportunity'
        ),
        highPriorityRecoveryOpportunity: toFiniteNumber(
          row.high_priority_recovery_opportunity ?? row.high_priority_recovery_opportunity_egp ?? 0,
          'high_priority_recovery_opportunity'
        ),
      })
    );
  },

  async riskDistribution(params: CustomerRiskDistributionParams = {}): Promise<CustomerRiskDistributionResult[]> {
    if (params.asOfDate) assertIsoDate(params.asOfDate, 'asOfDate');

    return callAnalyticsRpc(
      'analytics_customer_risk_distribution',
      {
        p_as_of_date: params.asOfDate ?? null,
        p_company_name: params.companyName ?? null,
        p_salesperson: params.salesperson ?? null,
      },
      (row) => ({
        riskLevel: String(row.risk_level ?? row.risk ?? 'LOW'),
        customersCount: toFiniteNumber(row.customers_count ?? row.customer_count ?? row.customers ?? 0, 'customers_count'),
        customersPct: toFiniteNumber(row.customers_pct ?? row.pct ?? row.percentage ?? 0, 'customers_pct'),
        recoveryOpportunity: toFiniteNumber(
          row.recovery_opportunity ?? row.recovery_value ?? row.recovery_opportunity_value ?? 0,
          'recovery_opportunity'
        ),
      })
    );
  },

  async actionCenter(params: CustomerActionCenterParams = {}): Promise<CustomerActionCenterResult[]> {
    if (params.asOfDate) assertIsoDate(params.asOfDate, 'asOfDate');

    const mapper = (row: any) => ({
      customerId: toFiniteNumber(row.customer_id, 'customer_id'),
      customerName: String(row.customer_name ?? ''),
      companyName: String(row.company_name ?? ''),
      salesperson: String(row.salesperson ?? row.current_salesperson ?? row.primary_salesperson ?? ''),
      priority: String(row.priority ?? row.action_priority ?? 'LOW'),
      actionType: String(row.action_type ?? 'MONITOR'),
      actionReason: String(row.action_reason ?? row.reason ?? ''),
      lastOrderDate: row.last_order_date ? String(row.last_order_date) : null,
      daysSinceLastOrder: toFiniteNumber(row.days_since_last_order ?? 0, 'days_since_last_order'),
      medianBuyingInterval: toFiniteNumber(row.median_buying_interval ?? row.median_interval ?? 0, 'median_buying_interval'),
      previous30dSales: toFiniteNumber(row.previous_30d_sales ?? row.previous_30day_sales ?? 0, 'previous_30d_sales'),
      recent30dSales: toFiniteNumber(row.recent_30d_sales ?? row.recent_30day_sales ?? 0, 'recent_30d_sales'),
      salesChangePct: row.sales_change_pct != null ? toFiniteNumber(row.sales_change_pct, 'sales_change_pct') : null,
      recoveryOpportunity: toFiniteNumber(row.recovery_opportunity ?? row.recovery_value ?? 0, 'recovery_opportunity'),
      risk: String(row.risk ?? row.risk_level ?? 'LOW'),
      salespersonChanged: Boolean(row.salesperson_changed ?? row.is_salesperson_changed ?? false),
    });

    try {
      return await callAnalyticsRpc(
        'analytics_customer_action_center_v2',
        {
          p_as_of_date: params.asOfDate ?? null,
          p_company_name: params.companyName ?? null,
          p_salesperson: params.salesperson ?? null,
          p_priority: params.priority ?? null,
          p_action_type: params.actionType ?? null,
          p_search: params.search ?? null,
          p_limit: params.limit ?? null,
          p_offset: params.offset ?? null,
          p_risk: params.risk ?? null,
        },
        mapper
      );
    } catch (_err: any) {
      let rows = await callAnalyticsRpc(
        'analytics_customer_action_center',
        {
          p_as_of_date: params.asOfDate ?? null,
          p_company_name: params.companyName ?? null,
          p_salesperson: params.salesperson ?? null,
          p_priority: params.priority ?? null,
          p_action_type: params.actionType ?? null,
          p_search: params.search ?? null,
          p_limit: params.limit ?? null,
          p_offset: params.offset ?? null,
        },
        mapper
      );

      if (params.risk) {
        const lowerRisk = params.risk.toLowerCase();
        rows = rows.filter((r) => r.risk.toLowerCase() === lowerRisk);
      }
      return rows;
    }
  },

  async recoveryOpportunities(params: CustomerRecoveryOpportunitiesParams = {}): Promise<CustomerRecoveryOpportunitiesResult[]> {
    if (params.asOfDate) assertIsoDate(params.asOfDate, 'asOfDate');

    return callAnalyticsRpc(
      'analytics_customer_recovery_opportunities',
      {
        p_as_of_date: params.asOfDate ?? null,
        p_company_name: params.companyName ?? null,
        p_salesperson: params.salesperson ?? null,
        p_limit: params.limit ?? null,
      },
      (row) => ({
        customerId: toFiniteNumber(row.customer_id, 'customer_id'),
        customerName: String(row.customer_name ?? ''),
        companyName: String(row.company_name ?? ''),
        salesperson: String(row.salesperson ?? row.responsible_salesperson ?? row.current_salesperson ?? ''),
        recoveryValue: toFiniteNumber(row.recovery_value ?? row.recovery_opportunity ?? 0, 'recovery_value'),
        previous30dSales: toFiniteNumber(row.previous_30d_sales ?? row.previous_30day_sales ?? 0, 'previous_30d_sales'),
        recent30dSales: toFiniteNumber(row.recent_30d_sales ?? row.recent_30day_sales ?? 0, 'recent_30d_sales'),
        salesDeclinePct:
          row.sales_decline_pct != null
            ? toFiniteNumber(row.sales_decline_pct, 'sales_decline_pct')
            : row.sales_change_pct != null
            ? toFiniteNumber(row.sales_change_pct, 'sales_change_pct')
            : null,
        daysSinceLastOrder: toFiniteNumber(row.days_since_last_order ?? 0, 'days_since_last_order'),
        actionReason: String(row.action_reason ?? row.reason ?? ''),
      })
    );
  },
};
